#!/bin/bash

for (( i=1; i<=9; i++ ))
do
    mv "ex_0$i/given.html" "ex_0$i/index.html"
done
