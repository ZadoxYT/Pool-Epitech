document.addEventListener('DOMContentLoaded', function() {
    const button = document.getElementById('addToCart')
    button.addEventListener('click', function() {
    alert("Thanks")
    })
});
