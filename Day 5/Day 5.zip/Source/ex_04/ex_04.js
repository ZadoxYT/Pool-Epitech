document.addEventListener('DOMContentLoaded', function() {
    let removesom = document.getElementById("tag")
    removesom.remove()
});
