let number=0;

function addTwo(){
	number+=2
}

addTwo()
addTwo()
addTwo()

displayThisNumber(number)