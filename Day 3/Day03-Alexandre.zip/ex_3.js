function changebackground() {
    var magicNumber = 1;
  
    if (magicNumber === 1) {
      paintYellowRectangle();
    }
    
    var magicNumber = 2;
    
    if (magicNumber === 2) {
      paintGreenRectangle();
    }
    
    var magicNumber = 3;
    
    if (magicNumber === 3) {
      paintRedRectangle();
    }
  }
  
  changebackground();  