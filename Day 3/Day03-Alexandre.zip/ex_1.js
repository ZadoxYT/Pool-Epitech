function sayHi() {
	console.log("Hi !")
  return
}

sayHi()
sayHi()