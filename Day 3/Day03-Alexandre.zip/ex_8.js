fruits = ["Blackberries", "Mango", "Kiwi", "Peaches", "Strawberry"];

function getFruit(index){
	return displayResult(index)
}

getFruit("Mango")