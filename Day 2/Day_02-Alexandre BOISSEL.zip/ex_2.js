var bool = true;
var string = "forty two";
var integer = 42;
var this_is_null = null;
var float = 42.42;

displayThisText(bool);
displayThisText(string);
displayThisText(integer);
displayThisText(this_is_null);
displayThisText(float);