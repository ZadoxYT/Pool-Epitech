displayThisText("The variable value is '"+ input_var +"'")
displayThisText("Its type is '"+ typeof input_var +"'")
if (input_var==42){
    displayThisText("It is the meaning of life.")
}