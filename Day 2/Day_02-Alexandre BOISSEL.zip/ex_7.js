if (password=="forty-two"){
	displayThisText("Success")
} else if (password !="forty-two") {
	displayThisText("Wrong password")
}