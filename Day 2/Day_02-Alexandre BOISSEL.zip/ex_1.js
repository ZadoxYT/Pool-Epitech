var greeting = "Hello World!";
displayThisText(greeting); // Commande pour afficher le texte sur Fidldle.