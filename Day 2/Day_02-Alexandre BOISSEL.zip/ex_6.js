if (bananasCount==0){
	displayThisText("Oh no, there is no banana.")
} else if (bananasCount >=0) {
	displayThisText("Yummy!")
} else if (bananasCount <=0) {
	displayThisText("Do I owe you bananas?")
}