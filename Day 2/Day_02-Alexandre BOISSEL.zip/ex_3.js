let number1 = "1";
let number2 = "2";

displayThisText(number1 + number2)