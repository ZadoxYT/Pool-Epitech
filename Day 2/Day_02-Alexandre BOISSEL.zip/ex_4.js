let boolean = true;
let symbol = Symbol("bonjour");
let object = Object.create(null);

displayThisText(typeof Poulet)
displayThisText(typeof boolean)
displayThisText(typeof 42)
displayThisText(typeof 9007199254740991n)
displayThisText(typeof symbol)
displayThisText(typeof object)
displayThisText(typeof displayThisText)